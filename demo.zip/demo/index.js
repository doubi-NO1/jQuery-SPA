$(function(){
    window.app = new App(config);
    app.start();
});