//# sourceURL=welcome/welcome.js
(function(){
    setTimeout(() => {
        window.location.hash="#table/table";
    }, 4000);
})();