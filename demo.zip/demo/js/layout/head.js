//# sourceURL=head.js
/**
 * head
 */
(function(window,$,undefined){
    
})(window,jQuery);
